from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.models import User

# Create your views here.
def home(request):
    if request.method == 'POST':
        uname = request.POST('username')
        mail = request.POST('email')

        User.object.create_user(username=uname,email=mail)

        return redirect('/')
    else:
        return render(request, 'index.html')

    